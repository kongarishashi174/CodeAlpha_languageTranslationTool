# AI Language Translator

A simple web app built with HTML, CSS and JavaScript. Type text, choose the source and target languages, and translate. You can copy the result or hear it read aloud.

## Features
- Text input (up to 5000 characters)
- Source language (with auto-detect) and target language dropdowns, plus a swap button
- Add your own custom language
- Translate button, clear result display
- Copy translated text and text-to-speech (Web Speech API)
- Light and dark mode, mobile friendly

## Run locally
Open `index.html` in a browser. No build step needed.

## Translation API
`script.js` has a `PROVIDER` setting at the top:

| Provider | Setup | Notes |
|----------|-------|-------|
| `mymemory` (default) | None | Free, no key, daily limits apply |
| `google` | Set `GOOGLE_API_KEY` | Google Cloud Translation API, billing applies. Restrict the key to your domain, because front-end keys are public |

## Deploy on GitHub Pages
1. Push these files to a repository.
2. Go to **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
4. Your site appears at `https://<username>.github.io/<repo>/`.

## Text-to-speech note
Voices come from your device. If a language has no installed voice, add one in your system's speech settings (Windows: Settings → Time & language → Speech). Microsoft Edge includes many online voices.
