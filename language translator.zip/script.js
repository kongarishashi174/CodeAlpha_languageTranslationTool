/* ===== CONFIG =====
   PROVIDER: "mymemory" (free, no key, works out of the box)
          or "google"   (Google Cloud Translation API, needs GOOGLE_API_KEY)
   WARNING: a key placed in front-end code is visible to everyone.
   If you use Google, restrict the key to your site's domain in Google Cloud Console,
   or route requests through your own backend. */
const PROVIDER = "mymemory";
const GOOGLE_API_KEY = "";

// [display name, API code, speech language code]
const LANGS = [
  ["English","en","en-US"],["Hindi","hi","hi-IN"],["Telugu","te","te-IN"],["Tamil","ta","ta-IN"],
  ["Kannada","kn","kn-IN"],["Malayalam","ml","ml-IN"],["Marathi","mr","mr-IN"],["Bengali","bn","bn-IN"],
  ["Gujarati","gu","gu-IN"],["Punjabi","pa","pa-IN"],["Urdu","ur","ur-PK"],["Spanish","es","es-ES"],
  ["French","fr","fr-FR"],["German","de","de-DE"],["Italian","it","it-IT"],["Portuguese","pt","pt-PT"],
  ["Russian","ru","ru-RU"],["Arabic","ar","ar-SA"],["Chinese (Simplified)","zh-CN","zh-CN"],
  ["Japanese","ja","ja-JP"],["Korean","ko","ko-KR"],["Turkish","tr","tr-TR"],["Dutch","nl","nl-NL"],
  ["Indonesian","id","id-ID"],["Thai","th","th-TH"],["Vietnamese","vi","vi-VN"]
];

const $ = id => document.getElementById(id);
const src = $("src"), tgt = $("tgt"), inp = $("inp"), out = $("out"), go = $("go"), note = $("note");
let lastText = "";

/* ---------- language dropdowns ---------- */
function addLang(name, code, tts) {
  for (const sel of [src, tgt]) {
    const o = document.createElement("option");
    o.value = code; o.textContent = name; o.dataset.tts = tts || "";
    sel.appendChild(o);
  }
}
const auto = document.createElement("option");
auto.value = "auto"; auto.textContent = "Detect language";
src.appendChild(auto);
LANGS.forEach(([n, c, t]) => addLang(n, c, t));
src.value = "auto"; tgt.value = "hi";

const langName = sel => sel.options[sel.selectedIndex].textContent;

/* ---------- UI helpers ---------- */
function setOut(text, cls) { out.textContent = text; out.className = "out" + (cls ? " " + cls : ""); }
function syncButtons() { $("copy").disabled = $("speak").disabled = !lastText; }
function resetOut() { lastText = ""; setOut("Translation will appear here...", "ph"); syncButtons(); }
inp.addEventListener("input", () => { $("count").textContent = inp.value.length + " / 5000"; });
inp.addEventListener("keydown", e => { if ((e.ctrlKey || e.metaKey) && e.key === "Enter") go.click(); });

$("clear").onclick = () => {
  inp.value = ""; $("count").textContent = "0 / 5000"; resetOut(); note.textContent = "";
  if ("speechSynthesis" in window) speechSynthesis.cancel();
};
$("addBtn").onclick = () => { $("customBox").classList.toggle("on"); $("customName").focus(); };
$("customSave").onclick = () => {
  const name = $("customName").value.trim(), code = $("customCode").value.trim();
  if (!name || !code) { note.textContent = "Enter both a language name and its code."; return; }
  addLang(name, code, "");
  tgt.value = code;
  $("customName").value = ""; $("customCode").value = "";
  $("customBox").classList.remove("on"); note.textContent = "";
};
$("swap").onclick = () => {
  if (src.value === "auto") { note.textContent = "Pick a specific source language to swap."; return; }
  const s = src.value; src.value = tgt.value; tgt.value = s;
  if (lastText) { inp.value = lastText; $("count").textContent = inp.value.length + " / 5000"; resetOut(); }
};

/* ---------- copy ---------- */
$("copy").onclick = async () => {
  try { await navigator.clipboard.writeText(lastText); $("copy").textContent = "Copied ✓"; }
  catch (e) {
    const r = document.createRange(); r.selectNodeContents(out);
    const s = getSelection(); s.removeAllRanges(); s.addRange(r); $("copy").textContent = "Selected";
  }
  setTimeout(() => $("copy").textContent = "Copy", 1500);
};

/* ---------- text to speech ---------- */
let VOICES = []; const keep = [];
function loadVoices() { try { VOICES = speechSynthesis.getVoices() || []; } catch (e) {} }
if ("speechSynthesis" in window) {
  loadVoices();
  speechSynthesis.addEventListener && speechSynthesis.addEventListener("voiceschanged", loadVoices);
}
function pickVoice(lang) {
  const p = lang.slice(0, 2).toLowerCase();
  return VOICES.find(v => v.lang.replace("_", "-").toLowerCase() === lang.toLowerCase())
      || VOICES.find(v => v.lang.slice(0, 2).toLowerCase() === p) || null;
}
$("speak").onclick = () => {
  note.textContent = "";
  if (!("speechSynthesis" in window)) { note.textContent = "Text-to-speech isn't supported in this browser."; return; }
  loadVoices();
  const lang = tgt.options[tgt.selectedIndex].dataset.tts || "";
  const voice = lang ? pickVoice(lang) : null;
  if (lang && !voice && VOICES.length) {
    note.textContent = "No " + langName(tgt) + " voice is installed on this device. Add one in your system's speech settings, then reload.";
    return;
  }
  speechSynthesis.cancel();
  const parts = (lastText.match(/[^.!?\u0964\u3002\uff01\uff1f\n]+[.!?\u0964\u3002\uff01\uff1f]*/g) || [lastText])
    .map(s => s.trim()).filter(Boolean);
  parts.forEach((s, i) => {
    const u = new SpeechSynthesisUtterance(s);
    if (lang) u.lang = lang;
    if (voice) u.voice = voice;
    u.onerror = ev => {
      if (ev.error && ev.error !== "canceled" && ev.error !== "interrupted")
        note.textContent = "Couldn't play audio (" + ev.error + ").";
    };
    keep.push(u); if (keep.length > 50) keep.shift();
    setTimeout(() => speechSynthesis.speak(u), i === 0 ? 60 : 0);
  });
  setTimeout(() => { if (speechSynthesis.paused) speechSynthesis.resume(); }, 200);
};

/* ---------- translation providers ---------- */
// Split text into pieces of at most `max` characters, keeping line breaks.
function chunk(text, max) {
  const pieces = [];
  for (const line of text.split("\n")) {
    if (!line.trim()) { pieces.push(""); continue; }
    const sentences = line.match(/[^.!?\u0964\u3002\uff01\uff1f]+[.!?\u0964\u3002\uff01\uff1f]*\s*/g) || [line];
    let cur = "";
    for (let s of sentences) {
      while (s.length > max) {            // very long sentence: cut at a space
        let cut = s.lastIndexOf(" ", max); if (cut < 1) cut = max;
        if (cur) { pieces.push(cur); cur = ""; }
        pieces.push(s.slice(0, cut)); s = s.slice(cut);
      }
      if ((cur + s).length > max) { pieces.push(cur); cur = s; } else cur += s;
    }
    if (cur) pieces.push(cur);
    pieces.push("\n");                    // marks end of line
  }
  return pieces;
}

async function myMemory(text, from, to) {
  const pair = (from === "auto" ? "Autodetect" : from) + "|" + to;
  const url = "https://api.mymemory.translated.net/get?q=" + encodeURIComponent(text) + "&langpair=" + encodeURIComponent(pair);
  const res = await fetch(url);
  if (!res.ok) throw new Error("Translation service error (" + res.status + ").");
  const data = await res.json();
  if (String(data.responseStatus) !== "200") {
    throw new Error(String(data.responseStatus) === "429"
      ? "Free daily limit reached. Try again later or switch to Google in script.js."
      : (data.responseDetails || "Translation failed."));
  }
  return data.responseData.translatedText;
}

async function googleTranslate(text, from, to) {
  if (!GOOGLE_API_KEY) throw new Error("Add your GOOGLE_API_KEY in script.js.");
  const body = { q: text, target: to, format: "text" };
  if (from !== "auto") body.source = from;
  const res = await fetch("https://translation.googleapis.com/language/translate/v2?key=" + GOOGLE_API_KEY, {
    method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body)
  });
  const data = await res.json();
  if (!res.ok) throw new Error((data.error && data.error.message) || "Google Translate error.");
  const d = document.createElement("textarea");   // decode any HTML entities
  d.innerHTML = data.data.translations[0].translatedText;
  return d.value;
}

async function translate(text, from, to) {
  if (PROVIDER === "google") return googleTranslate(text, from, to);
  let result = "";
  for (const piece of chunk(text, 450)) {
    if (piece === "\n") result += "\n";
    else if (piece === "") continue;
    else result += await myMemory(piece, from, to);
  }
  return result.trim();
}

/* ---------- translate button ---------- */
go.onclick = async () => {
  const text = inp.value.trim();
  note.textContent = "";
  if (!text) { setOut("Please enter some text to translate.", "err"); return; }
  if (src.value === tgt.value) { setOut("Source and target languages are the same.", "err"); return; }
  go.disabled = true; go.textContent = "Translating...";
  lastText = ""; syncButtons(); setOut("Translating...", "ph");
  try {
    lastText = (await translate(text, src.value, tgt.value)).trim();
    setOut(lastText || "No translation returned.", lastText ? "" : "err");
  } catch (e) {
    setOut(e.message || "Translation failed. Please try again.", "err");
  } finally {
    go.disabled = false; go.textContent = "Translate"; syncButtons();
  }
};
